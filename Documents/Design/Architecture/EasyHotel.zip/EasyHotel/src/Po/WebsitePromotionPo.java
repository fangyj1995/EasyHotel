package Po;

import java.util.Date;

public class WebsitePromotionPo extends PromotionPo{
	public WebsitePromotionPo(String id, Date start_time, Date end_time, double discount, int member_level) {
		super(id, start_time, end_time, discount, member_level);
		// TODO Auto-generated constructor stub
	}

	String area;

	

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	
}
