package Po;

import java.util.Date;

public class HotelPromotionPo extends PromotionPo {
	public HotelPromotionPo(String id, Date start_time, Date end_time, double discount, int member_level) {
		super(id, start_time, end_time, discount, member_level);
		// TODO Auto-generated constructor stub
	}
	Date birthday;
	int room_number;
	String enterprise_name;
	public HotelPromotionPo(String id, Date start_time, Date end_time, double discount, int member_level, Date birthday,
			int room_number, String enterprise_name) {
		super(id, start_time, end_time, discount, member_level);
		this.birthday = birthday;
		this.room_number = room_number;
		this.enterprise_name = enterprise_name;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public String getEnterprise_name() {
		return enterprise_name;
	}
	public void setEnterprise_name(String enterprise_name) {
		this.enterprise_name = enterprise_name;
	}
	
}
