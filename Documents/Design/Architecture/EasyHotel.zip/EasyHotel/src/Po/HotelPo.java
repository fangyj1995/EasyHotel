package Po;

public class HotelPo {
	String id;
	String name;
	String address;
	String city;
	String area;
	String introduction;
	String facility;//设施服务
	int star_level;
	public HotelPo(String id, String name, String address, String city, String area, String introduction,
			String facility, int star_level) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.city = city;
		this.area = area;
		this.introduction = introduction;
		this.facility = facility;
		this.star_level = star_level;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getFacility() {
		return facility;
	}
	public void setFacility(String facility) {
		this.facility = facility;
	}
	public int getStar_level() {
		return star_level;
	}
	public void setStar_level(int star_level) {
		this.star_level = star_level;
	}
	
	


}