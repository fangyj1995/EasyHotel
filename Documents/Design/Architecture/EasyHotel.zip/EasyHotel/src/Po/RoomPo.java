package Po;

public class RoomPo {
	String id;
	int number;
	int available_number;
	double original_price;
	public RoomPo(String id, int number, int available_number, double original_price) {
		super();
		this.id = id;
		this.number = number;
		this.available_number = available_number;
		this.original_price = original_price;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getAvailable_number() {
		return available_number;
	}
	public void setAvailable_number(int available_number) {
		this.available_number = available_number;
	}
	public double getOriginal_price() {
		return original_price;
	}
	public void setOriginal_price(double original_price) {
		this.original_price = original_price;
	}
	
	
}
