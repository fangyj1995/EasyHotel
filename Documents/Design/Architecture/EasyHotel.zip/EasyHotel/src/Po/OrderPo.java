package Po;

import java.util.Date;

public class OrderPo {
	String id;
	String hotel;
	Date check_in_time;
	Date check_out_time;
	Date last_time;//最晚订单执行时间
	String room_type;
	int room_number;
	int expected_number;//预计入住人数
	Boolean is_children;
	int status;
	Date cancel_time;
	public OrderPo(String id, String hotel, Date check_in_time, Date check_out_time, Date last_time, String room_type,
			int room_number, int expected_number, Boolean is_children, int status, Date cancel_time) {
		super();
		this.id = id;
		this.hotel = hotel;
		this.check_in_time = check_in_time;
		this.check_out_time = check_out_time;
		this.last_time = last_time;
		this.room_type = room_type;
		this.room_number = room_number;
		this.expected_number = expected_number;
		this.is_children = is_children;
		this.status = status;
		this.cancel_time = cancel_time;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getHotel() {
		return hotel;
	}
	public void setHotel(String hotel) {
		this.hotel = hotel;
	}
	public Date getCheck_in_time() {
		return check_in_time;
	}
	public void setCheck_in_time(Date check_in_time) {
		this.check_in_time = check_in_time;
	}
	public Date getCheck_out_time() {
		return check_out_time;
	}
	public void setCheck_out_time(Date check_out_time) {
		this.check_out_time = check_out_time;
	}
	public Date getLast_time() {
		return last_time;
	}
	public void setLast_time(Date last_time) {
		this.last_time = last_time;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public int getExpected_number() {
		return expected_number;
	}
	public void setExpected_number(int expected_number) {
		this.expected_number = expected_number;
	}
	public Boolean getIs_children() {
		return is_children;
	}
	public void setIs_children(Boolean is_children) {
		this.is_children = is_children;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getCancel_time() {
		return cancel_time;
	}
	public void setCancel_time(Date cancel_time) {
		this.cancel_time = cancel_time;
	}
	
	
	
}
