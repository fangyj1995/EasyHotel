package Controller.Driver;

import java.util.List;

import Model.Service.MemberService.MemberService;
import Model.Service.Stub.MemberService_Stub;
import Po.MemberPo;
import Tool.OpMessage;
import Tool.SearchCondition;
import Vo.HotelVo;
import Vo.MemberVo;

public class Member_Driver {
	public Member_Driver(MemberService memberController) {
		// TODO Auto-generated constructor stub
	}

	public void drive(MemberService memberService){
		
		SearchCondition con = null;
		String key = null;
		String memberId = null;
		MemberPo member = null;
		
		List<MemberVo> result1 = memberService.searchMember(con);
		List<MemberVo> result2 =  memberService.searchMember(key);
		MemberVo result3 = memberService.getMember(memberId);
		List<MemberVo> result4 = memberService.getMembers();
		OpMessage result5 = memberService.addMember(member);
		OpMessage result6 = memberService.modifyMember(member);
		OpMessage result7 =  memberService.deleteMember(memberId);
	}
	
	public class Controller{
		public void main(String[] args){
			MemberService_Stub memberController = new MemberService_Stub();
			Member_Driver driver = new Member_Driver(memberController);
			driver.drive(memberController);
		}
	}
}
