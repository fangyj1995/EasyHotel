package Controller.Driver;

import java.util.List;

import Model.Service.RoomService.RoomService;
import Model.Service.Stub.RoomService_Stub;
import Po.RoomPo;
import Tool.OpMessage;
import Vo.RoomVo;

public class Room_Driver {
	public Room_Driver(RoomService roomController) {
		// TODO Auto-generated constructor stub
	}

	public void drive(RoomService roomService){
		String roomId = null;
		String hotelId = null;
		RoomPo room = null;
		
		RoomVo result1 = roomService.getRoom(roomId);
		List<RoomVo> result2 = roomService.getAllRoomsByHotel (hotelId);
		OpMessage result3 = roomService.deleteRoom(roomId);
		OpMessage result4 = roomService.modifyRoom(room);
		OpMessage result5 = roomService.addRoom(room);
	}
	
	public class Controller{
		public void main(String[] args){
			RoomService_Stub roomController = new RoomService_Stub();
			Room_Driver driver = new Room_Driver(roomController);
			driver.drive(roomController);
		}
	}
}
