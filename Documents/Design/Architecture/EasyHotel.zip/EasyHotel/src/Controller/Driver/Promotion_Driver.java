package Controller.Driver;

import java.util.List;

import Model.Service.PromotionService.PromotionService;
import Model.Service.Stub.PromotionService_Stub;
import Po.PromotionPo;
import Tool.OpMessage;
import Vo.PromotionVo;

public class Promotion_Driver {
	public Promotion_Driver(PromotionService promotionController) {
		// TODO Auto-generated constructor stub
	}

	public void drive(PromotionService promotionService){
		
		String promotionId = null;
		String hotelId = null;
		PromotionPo promotion = null;
		
		
		PromotionVo result1 = promotionService.getPromotion (promotionId);
		List<PromotionVo> result2 = promotionService.getHotelPromotions(hotelId);
		List<PromotionVo> result3 = promotionService.getSitePromotions();
		OpMessage result4 = promotionService.addPromotion (promotion);
		OpMessage result5 = promotionService.modifyPromotion (promotion);
		OpMessage result6 = promotionService.deletePromotion (promotionId);
	}
	
	public class Controller{
		public void main(String[] args){
			PromotionService_Stub promotionController = new PromotionService_Stub();
			Promotion_Driver driver = new Promotion_Driver(promotionController);
			driver.drive(promotionController);
		}
	}
}
