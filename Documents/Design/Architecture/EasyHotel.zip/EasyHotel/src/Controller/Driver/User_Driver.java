package Controller.Driver;

import java.util.List;

import Model.Service.Stub.UserService_Stub;
import Model.Service.UserService.UserService;
import Po.UserPo;
import Tool.OpMessage;
import Tool.SearchCondition;
import Vo.MemberVo;
import Vo.UserVo;

public class User_Driver {
	public User_Driver(UserService userController) {
		// TODO Auto-generated constructor stub
	}

	public void drive(UserService userService){
		SearchCondition con = new SearchCondition();
		String userId = null;
		UserPo user = null;
		MemberVo member = null;
		UserVo user1 = null;
		MemberVo member1 = null;
		
		List<UserVo> result1 = userService.searchUsers(con);
		UserVo result2 =  userService.getUser(userId);
		List<UserVo> result3 = userService.getUsers();
		OpMessage result4 = userService.addUser (user);
		OpMessage result5 = userService.modifyUser (user);
		OpMessage result6 = userService.deleteUser (userId);
		OpMessage result7 = userService.memberLogin(member);
		OpMessage result8 = userService.userLogin(user1);
		OpMessage result9 = userService.memberRegister(member1);
	}
	
	public class Controller{
		public void main(String[] args){
			UserService_Stub userController = new UserService_Stub();
			User_Driver driver = new User_Driver(userController);
			driver.drive(userController);
		}
	}
}
