package Controller.Driver;
import java.util.List;
import Model.Service.Stub.HotelService_Stub;

import Model.Service.HotelService.HotelService;
import Po.HotelPo;
import Tool.OpMessage;
import Tool.SearchCondition;
import Tool.SortCondition;
import Vo.HotelVo;

public class Hotel_Driver {
	public Hotel_Driver(HotelService hotelController) {
		// TODO Auto-generated constructor stub
	}

	public void drive(HotelService hotelService){
		
		SearchCondition srechCondition = new SearchCondition();
		SortCondition con = new SortCondition();
		List<HotelVo> hotels = null;
		HotelPo hotel = new HotelPo(null, null, null, null, null, null, null, 0);
		
		HotelVo result1= hotelService.getHotel("111");
		List<HotelVo> result2 = hotelService.getAllHotels();
		List<HotelVo> result3 = hotelService.searchHotels(srechCondition);
		List<HotelVo> reult4 =  hotelService.sortHotels(hotels,con);
		OpMessage result5 = hotelService.addHotel(hotel);
		OpMessage result6 = hotelService.deleteHotel("222");
		OpMessage result7 =  hotelService.modifyHotel(hotel);
	}
	
	public class Controller{
		public void main(String[] args){
			HotelService_Stub hotelController = new HotelService_Stub();
			Hotel_Driver driver = new Hotel_Driver(hotelController);
			driver.drive(hotelController);
		}
	}
}
