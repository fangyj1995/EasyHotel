package Controller.Driver;

import java.util.List;

import Model.Service.OrderService.OrderService;
import Model.Service.Stub.OrderService_Stub;
import Po.OrderPo;
import Tool.OpMessage;
import Vo.OrderVo;

public class Order_Driver {
	public Order_Driver(OrderService orderController) {
		// TODO Auto-generated constructor stub
	}

	public void drive(OrderService orderService){
		
		OrderPo order = null;
		String orderId = null;
		String customerId = null;
		String hotelId = null;
		String state = null;
		String memberId = null;
		String promotionId = null;
		
		List<OrderVo> result1 = orderService.getAllOrdersByCustomer (customerId);
		List<OrderVo> result2 = orderService.getAllOrdersByHotel(hotelId);
		List<OrderVo> result3 = orderService.getAllCustomerOrdersByState (customerId,state);
		List<OrderVo> result4 = orderService.getAllHotelOrdersByState (hotelId,state);
		OrderVo result5 = orderService.getOrder(orderId) ;
		OpMessage result6 = orderService.placeOrder(order,memberId,hotelId,promotionId);
		OpMessage result7 = orderService.revokeOrder(orderId);
	}
	
	public class Controller{
		public void main(String[] args){
			OrderService_Stub orderController = new OrderService_Stub();
			Order_Driver driver = new Order_Driver(orderController);
			driver.drive(orderController);
		}
	}

}
