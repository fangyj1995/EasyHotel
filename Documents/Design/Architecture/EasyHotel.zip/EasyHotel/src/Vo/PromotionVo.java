package Vo;

import java.util.Date;

public class PromotionVo {
	String id;
	Date start_time;
	Date end_time;
	double discount;
	int member_level;
	public PromotionVo(String id, Date start_time, Date end_time, double discount, int member_level) {
		super();
		this.id = id;
		this.start_time = start_time;
		this.end_time = end_time;
		this.discount = discount;
		this.member_level = member_level;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getStart_time() {
		return start_time;
	}
	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}
	public Date getEnd_time() {
		return end_time;
	}
	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public int getMember_level() {
		return member_level;
	}
	public void setMember_level(int member_level) {
		this.member_level = member_level;
	}
	
}
