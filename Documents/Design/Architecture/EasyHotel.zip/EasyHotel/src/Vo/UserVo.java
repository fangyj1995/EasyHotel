package Vo;

public class UserVo {
	String id;
	String account;//工号
	String name;
	String password;
	String hotel_id;//酒店工作人员有
	public UserVo(String id, String account, String name, String password, String hotel_id) {
		super();
		this.id = id;
		this.account = account;
		this.name = name;
		this.password = password;
		this.hotel_id = hotel_id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}
	
}
