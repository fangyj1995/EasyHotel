package Vo;

import java.util.Date;

public class MemberVo {
	String id;
	String account;
	String password;
	String phone;
	int credit;
	int level;
	int type;//会员类别：企业会员，个人会员
	Date birthday;
	String enterprise_name;
	public MemberVo(String id, String account, String password, String phone, int credit, int level, int type,
			Date birthday, String enterprise_name) {
		super();
		this.id = id;
		this.account = account;
		this.password = password;
		this.phone = phone;
		this.credit = credit;
		this.level = level;
		this.type = type;
		this.birthday = birthday;
		this.enterprise_name = enterprise_name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getCredit() {
		return credit;
	}
	public void setCredit(int credit) {
		this.credit = credit;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getEnterprise_name() {
		return enterprise_name;
	}
	public void setEnterprise_name(String enterprise_name) {
		this.enterprise_name = enterprise_name;
	}
	
}
