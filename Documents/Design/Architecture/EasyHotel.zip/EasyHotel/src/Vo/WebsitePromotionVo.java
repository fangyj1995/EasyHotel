package Vo;

import java.util.Date;

public class WebsitePromotionVo extends PromotionVo {
	public WebsitePromotionVo(String id, Date start_time, Date end_time, double discount, int member_level) {
		super(id, start_time, end_time, discount, member_level);
		// TODO Auto-generated constructor stub
	}

	String area;

	public WebsitePromotionVo(String id, Date start_time, Date end_time, double discount, int member_level,
			String area) {
		super(id, start_time, end_time, discount, member_level);
		this.area = area;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	
}
