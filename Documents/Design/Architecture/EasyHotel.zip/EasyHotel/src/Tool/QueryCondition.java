package Tool;

public class QueryCondition {

}
