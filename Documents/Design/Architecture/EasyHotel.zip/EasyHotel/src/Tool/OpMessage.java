package Tool;

public class OpMessage {
	
}
