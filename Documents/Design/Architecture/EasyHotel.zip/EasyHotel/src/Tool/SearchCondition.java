package Tool;

public class SearchCondition {

}
