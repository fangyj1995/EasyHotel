package Tool;

public class SortCondition {

}
