package Model.Dao.Stub;

import java.util.ArrayList;
import java.util.List;

import Model.Dao.HotelDao.HotelDao;
import Po.HotelPo;
import Tool.OpMessage;
import Tool.QueryCondition;

public class HotelDao_Stub implements HotelDao{

	@Override
	public OpMessage insert(HotelPo hotel) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public List<HotelPo> query(QueryCondition con) {
		// TODO Auto-generated method stub
		return new ArrayList<HotelPo>();
	}

	@Override
	public List<HotelPo> getAllHotels() {
		// TODO Auto-generated method stub
		return new ArrayList<HotelPo>();
	}

	@Override
	public HotelPo getHotelById(String hoteld) {
		// TODO Auto-generated method stub
		return new HotelPo("123", "XX酒店", "南京市汉口路", "南京", "鼓楼区", "介绍", "设施", 3); 
	}

	@Override
	public OpMessage delete(String hotelId) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage update(HotelPo hotel) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

}
