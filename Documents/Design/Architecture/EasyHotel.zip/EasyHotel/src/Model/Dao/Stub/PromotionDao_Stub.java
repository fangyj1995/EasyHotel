package Model.Dao.Stub;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Model.Dao.PromotionDao.PromotionDao;
import Po.PromotionPo;
import Tool.OpMessage;
import Vo.PromotionVo;

public class PromotionDao_Stub implements PromotionDao{

	@Override
	public OpMessage insert(PromotionVo promotion) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage delete(String promotionId) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage update(PromotionVo promotion) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public PromotionPo getPromotionById(String id) {
		// TODO Auto-generated method stub
		return new PromotionPo("123", new Date(), new Date(), 0.7, 3);
	}

	@Override
	public List<PromotionPo> getAllPromotionsByHotel(String HotelId) {
		// TODO Auto-generated method stub
		return new ArrayList<PromotionPo>();
	}

	@Override
	public List<PromotionPo> getAllSitePromotions() {
		// TODO Auto-generated method stub
		return  new ArrayList<PromotionPo>();
	}

}
