package Model.Dao.UserDao;

import java.util.List;

import Po.UserPo;
import Tool.OpMessage;
import Tool.QueryCondition;

public interface UserDao {
	public OpMessage insert(UserPo user);
	public OpMessage delete(String userId);
	public OpMessage update(UserPo user);
	public UserPo getUserById(String userId);
	public List<UserPo> getAllUsers();
	public List<UserPo> query(QueryCondition con);
}