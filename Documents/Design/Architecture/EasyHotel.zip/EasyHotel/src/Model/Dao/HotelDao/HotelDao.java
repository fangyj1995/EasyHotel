package Model.Dao.HotelDao;

import java.util.List;

import Po.HotelPo;
import Tool.QueryCondition;
import Tool.OpMessage;

public interface HotelDao {
	public OpMessage insert (HotelPo hotel);
	public List<HotelPo> query(QueryCondition con);
	public List<HotelPo> getAllHotels();
	public HotelPo getHotelById(String hoteld);
	public OpMessage delete (String hotelId);
	public OpMessage update(HotelPo hotel);
}
