package Model.Dao.MemberDao;

import java.util.List;

import Po.MemberPo;
import Tool.QueryCondition;
import Tool.OpMessage;

public interface MemberDao {
	public OpMessage insert(MemberPo member);
	public OpMessage delete(String memberId);
	public OpMessage update(MemberPo member);
	public List<MemberPo> query(QueryCondition con);
	public MemberPo getMemberById(String MemberId);
	public MemberPo getMemberByName(String name);
	public List<MemberPo> getAllMembers();
}
