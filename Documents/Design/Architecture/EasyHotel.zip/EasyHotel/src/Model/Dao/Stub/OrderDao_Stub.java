package Model.Dao.Stub;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Model.Dao.OrderDao.OrderDao;
import Po.OrderPo;
import Tool.OpMessage;

public class OrderDao_Stub implements OrderDao{

	@Override
	public OpMessage insert(OrderPo order) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage delete(String OrderId) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage update(OrderPo order) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OrderPo getOrderById(String orderId) {
		// TODO Auto-generated method stub
		return new OrderPo("1234", "酒店", new Date(), new Date(), new Date(),"双人间", 3, 3, true, 1, new Date());
	}

	@Override
	public List<OrderPo> getAllOrdersbyCustomer(String customerId) {
		// TODO Auto-generated method stub
		return new ArrayList<OrderPo>();
	}

	@Override
	public ArrayList<OrderPo> getAllOrdersByHotel(String hotelId) {
		// TODO Auto-generated method stub
		return new ArrayList<OrderPo>();
	}

	@Override
	public ArrayList<OrderPo> getAllCustomerOrdersByState(String state, String customrId) {
		// TODO Auto-generated method stub
		return new ArrayList<OrderPo>();
	}

	@Override
	public ArrayList<OrderPo> getAllHotelOrdersByState(String state, String hotelId) {
		// TODO Auto-generated method stub
		return new ArrayList<OrderPo>();
	}

}
