package Model.Dao.OrderDao;

import java.util.List;

import Po.OrderPo;
import Tool.OpMessage;

public interface OrderDao {
	public OpMessage insert(OrderPo order);
	public OpMessage delete(String OrderId);
	public OpMessage update(OrderPo order);
	public OrderPo getOrderById(String orderId);
	public List<OrderPo> getAllOrdersbyCustomer(String customerId);
	public List<OrderPo> getAllOrdersByHotel(String hotelId);
	public List<OrderPo> getAllCustomerOrdersByState(String state,String customrId);
	public List<OrderPo> getAllHotelOrdersByState(String state,String hotelId);
	
}
