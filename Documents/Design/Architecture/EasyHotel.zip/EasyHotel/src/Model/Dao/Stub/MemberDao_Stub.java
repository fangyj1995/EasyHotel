package Model.Dao.Stub;

import java.util.ArrayList;
import java.util.List;

import Model.Dao.MemberDao.MemberDao;
import Po.MemberPo;
import Tool.OpMessage;
import Tool.QueryCondition;

public class MemberDao_Stub implements MemberDao{

	@Override
	public OpMessage insert(MemberPo member) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage delete(String memberId) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage update(MemberPo member) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public List<MemberPo> query(QueryCondition con) {
		// TODO Auto-generated method stub
		return new ArrayList<MemberPo>();
	}

	@Override
	public MemberPo getMemberById(String MemberId) {
		// TODO Auto-generated method stub
		return new MemberPo("123", "niruhe", "pwd", "13678229387", 23, 3, 2, null, MemberId);
	}

	@Override
	public MemberPo getMemberByName(String name) {
		// TODO Auto-generated method stub
		return new MemberPo("123", "niruhe", "pwd", "13678229387", 23, 3, 2, null, name);
	}

	@Override
	public List<MemberPo> getAllMembers() {
		// TODO Auto-generated method stub
		return new ArrayList<MemberPo>();
	}

}
