package Model.Dao.PromotionDao;

import java.util.List;

import Po.PromotionPo;
import Tool.OpMessage;
import Vo.PromotionVo;

public interface PromotionDao {
	public OpMessage insert(PromotionVo promotion);
	public OpMessage delete(String promotionId);
	public OpMessage update(PromotionVo promotion);
	public PromotionPo getPromotionById(String id);
	public List<PromotionPo> getAllPromotionsByHotel(String HotelId);
	public List<PromotionPo> getAllSitePromotions();
}
