package Model.Dao.Stub;

import java.util.ArrayList;
import java.util.List;

import Model.Dao.RoomDao.RoomDao;
import Po.RoomPo;
import Tool.OpMessage;

public class RoomDao_Stub implements RoomDao{

	@Override
	public OpMessage insert(RoomPo room) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage delete(String roomId) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage update(RoomPo room) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public RoomPo getRoomById(String roomId) {
		// TODO Auto-generated method stub
		return new RoomPo("123", 3, 2, 123);
	}

	@Override
	public List<RoomPo> getAllRoomsByHotel(String hotelId) {
		// TODO Auto-generated method stub
		return new ArrayList<RoomPo>();
	}

}
