package Model.Dao.Stub;

import java.util.ArrayList;
import java.util.List;

import Model.Dao.UserDao.UserDao;
import Po.UserPo;
import Tool.OpMessage;
import Tool.QueryCondition;

public class UserDao_Stub implements UserDao{

	@Override
	public OpMessage insert(UserPo user) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage delete(String userId) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage update(UserPo user) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public UserPo getUserById(String userId) {
		// TODO Auto-generated method stub
		return new UserPo("123", "werr", "李四", "wef", "123");
	}

	@Override
	public List<UserPo> getAllUsers() {
		// TODO Auto-generated method stub
		return new ArrayList<UserPo>();
	}

	@Override
	public List<UserPo> query(QueryCondition con) {
		// TODO Auto-generated method stub
		return new ArrayList<UserPo>();
	}

}
