package Model.Dao.RoomDao;

import java.util.List;

import Po.RoomPo;
import Tool.OpMessage;

public interface RoomDao {
	public OpMessage insert(RoomPo room);
	public OpMessage delete(String roomId);
	public OpMessage update(RoomPo room);
	public RoomPo getRoomById(String roomId);
	public List<RoomPo> getAllRoomsByHotel(String hotelId);
}
