package Model.Service.MemberService;

import java.util.List;

import Po.MemberPo;
import Tool.SearchCondition;
import Tool.OpMessage;
import Vo.MemberVo;

public interface MemberService {
	public List<MemberVo> searchMember(SearchCondition con);
	public List<MemberVo> searchMember(String key);
	public MemberVo getMember(String memberId);
	public List<MemberVo> getMembers();
	public OpMessage addMember(MemberPo member);
	public OpMessage modifyMember(MemberPo member);
	public OpMessage deleteMember(String memberId);
}
