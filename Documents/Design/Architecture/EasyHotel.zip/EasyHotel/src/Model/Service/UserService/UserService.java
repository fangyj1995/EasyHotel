package Model.Service.UserService;

import java.util.List;

import Po.UserPo;
import Tool.OpMessage;
import Tool.SearchCondition;
import Vo.MemberVo;
import Vo.UserVo;

public interface UserService {
	public List<UserVo> searchUsers(SearchCondition con);
	public UserVo getUser (String userId);
	public List<UserVo> getUsers();
	public OpMessage addUser (UserPo user);
	public OpMessage modifyUser (UserPo user);
	public OpMessage deleteUser (String userId);
	public OpMessage memberLogin(MemberVo member);
	public OpMessage userLogin(UserVo user);
	public OpMessage memberRegister(MemberVo member);
}
