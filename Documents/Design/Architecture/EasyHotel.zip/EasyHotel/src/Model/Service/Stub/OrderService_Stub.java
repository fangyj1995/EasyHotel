/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Service.Stub;

import Model.Service.OrderService.OrderService;
import Po.OrderPo;
import Tool.OpMessage;
import Vo.OrderVo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author dell
 */
public class OrderService_Stub implements OrderService{

    @Override
    public List<OrderVo> getAllOrdersByCustomer(String customer_Id) {
        List<OrderVo> lov=new ArrayList<OrderVo>();//To change body of generated methods, choose Tools | Templates.
        return lov;
    }

    @Override
    public List<OrderVo> getAllOrdersByHotel(String hotelId) {
        List<OrderVo> lov=new ArrayList<OrderVo>();//To change body of generated methods, choose Tools | Templates.
        return lov;
    }

    @Override
    public List<OrderVo> getAllCustomerOrdersByState(String customerId, String state) {
        List<OrderVo> lov=new ArrayList<OrderVo>();//To change body of generated methods, choose Tools | Templates.
        return lov;
    }

    @Override
    public List<OrderVo> getAllHotelOrdersByState(String hotelId, String state) {
        List<OrderVo> lov=new ArrayList<OrderVo>();//To change body of generated methods, choose Tools | Templates.
        return lov;
    }

    @Override
    public OrderVo getOrder(String orderId) {
        String hotel="rujia";
	Date check_in_time=new Date();
	Date check_out_time=new Date();
	Date last_time=new Date();//最晚订单执行时间
	String room_type="shuangrenjian";
	int room_number=2;
	int expected_number=4;//预计入住人数
	Boolean is_children=false;
	int status=1;
	Date cancel_time=new Date();
        OrderVo ov=new OrderVo(orderId,hotel,check_in_time,check_out_time,last_time,room_type,room_number,expected_number,is_children,status,cancel_time);//To change body of generated methods, choose Tools | Templates.
        return ov;
    }

    @Override
    public OpMessage placeOrder(OrderPo order, String memberId, String hotelId, String promotionId) {
        return new OpMessage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage revokeOrder(String OrderId) {
        return new OpMessage();//To change body of generated methods, choose Tools | Templates.
    }
    
}
