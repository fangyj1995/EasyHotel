package Model.Service.PromotionService;

import java.util.List;

import Po.PromotionPo;
import Tool.OpMessage;
import Vo.PromotionVo;

public interface PromotionService {
	public PromotionVo getPromotion (String promotionId);
	public List<PromotionVo> getHotelPromotions(String hotelId);
	public List<PromotionVo> getSitePromotions();
	public OpMessage addPromotion (PromotionPo promotion);
	public OpMessage modifyPromotion (PromotionPo promotion);
	public OpMessage deletePromotion (String promotionId);
}
