package Model.Service.Stub;

import java.util.ArrayList;
import java.util.List;

import Model.Service.UserService.UserService;
import Po.UserPo;
import Tool.OpMessage;
import Tool.SearchCondition;
import Vo.MemberVo;
import Vo.UserVo;

public class UserService_Stub implements UserService{

	@Override
	public List<UserVo> searchUsers(SearchCondition con) {
		// TODO Auto-generated method stub
		return new ArrayList<UserVo>();
	}

	@Override
	public UserVo getUser(String userId) {
		// TODO Auto-generated method stub
		return new UserVo("23", "wef", "李四", "r34", "23");
	}

	@Override
	public List<UserVo> getUsers() {
		// TODO Auto-generated method stub
		return new ArrayList<UserVo>();
	}

	@Override
	public OpMessage addUser(UserPo user) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage modifyUser(UserPo user) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage deleteUser(String userId) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage memberLogin(MemberVo member) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage userLogin(UserVo user) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

	@Override
	public OpMessage memberRegister(MemberVo member) {
		// TODO Auto-generated method stub
		return new OpMessage();
	}

}
