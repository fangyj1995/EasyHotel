package Model.Service.HotelService;

import java.util.List;

import Po.HotelPo;
import Tool.SearchCondition;
import Tool.SortCondition;
import Tool.OpMessage;
import Vo.HotelVo;

public interface HotelService {
	public HotelVo getHotel(String hotelId);
	public List<HotelVo>getAllHotels();
	public List<HotelVo> searchHotels(SearchCondition con);
	public List<HotelVo> sortHotels(List<HotelVo> hotels ,SortCondition con);
	public OpMessage addHotel(HotelPo hotel);
	public OpMessage deleteHotel(String hotelId);
	public OpMessage modifyHotel(HotelPo hotel);
}