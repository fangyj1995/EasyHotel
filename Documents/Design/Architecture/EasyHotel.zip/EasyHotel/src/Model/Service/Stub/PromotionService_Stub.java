/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Service.Stub;
import Model.Service.PromotionService.PromotionService;
import Po.PromotionPo;
import Tool.OpMessage;
import Vo.PromotionVo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author dell
 */
public class PromotionService_Stub implements PromotionService{

    @Override
    public PromotionVo getPromotion(String promotionId) {
        return new PromotionVo(promotionId,new Date(),new Date(),0.80,2);
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<PromotionVo> getHotelPromotions(String hotelId) {
         List<PromotionVo> lpv=new ArrayList<PromotionVo>();//To change body of generated methods, choose Tools | Templates.
        return lpv;
    }

    @Override
    public List<PromotionVo> getSitePromotions() {
        List<PromotionVo> lpv=new ArrayList<PromotionVo>();//To change body of generated methods, choose Tools | Templates.
        return lpv;
    }

    @Override
    public OpMessage addPromotion(PromotionPo promotion) {
         return new OpMessage();//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage modifyPromotion(PromotionPo promotion) {
         return new OpMessage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage deletePromotion(String promotionId) {
         return new OpMessage(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
