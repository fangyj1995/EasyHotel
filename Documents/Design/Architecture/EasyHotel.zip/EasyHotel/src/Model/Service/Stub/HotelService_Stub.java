/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Service.Stub;
import Model.Service.HotelService.HotelService;
import Po.HotelPo;
import Tool.OpMessage;
import Tool.SearchCondition;
import Tool.SortCondition;
import Vo.HotelVo;
import java.util.*;
/**
 *
 * @author dell
 */
public class HotelService_Stub implements HotelService{

    @Override
    public HotelVo getHotel(String hotelId) {
        String name="rujia",address="jiangsu",city="nanjing",area="gulouoqu",introduction="kuaijiejiudian",facility="wifi";
        HotelVo hv=new HotelVo(hotelId,name,address,city,area,introduction,facility,3);
        return hv;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<HotelVo> getAllHotels() {
        List<HotelVo> lhv=new ArrayList<HotelVo>();//To change body of generated methods, choose Tools | Templates.
        return lhv;
    }

    @Override
    public List<HotelVo> searchHotels(SearchCondition con) {
        List<HotelVo> lhv=new ArrayList<HotelVo>();//To change body of generated methods, choose Tools | Templates.
        return lhv; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<HotelVo> sortHotels(List<HotelVo> hotels, SortCondition con) {
        List<HotelVo> lhv=new ArrayList<HotelVo>();//To change body of generated methods, choose Tools | Templates.
        return lhv; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage addHotel(HotelPo hotel) {
        OpMessage om=new OpMessage();
        return om;
    }

    @Override
    public OpMessage deleteHotel(String hotelId) {
        OpMessage om=new OpMessage();
        return om; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage modifyHotel(HotelPo hotel) {
        OpMessage om=new OpMessage();
        return om; //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
