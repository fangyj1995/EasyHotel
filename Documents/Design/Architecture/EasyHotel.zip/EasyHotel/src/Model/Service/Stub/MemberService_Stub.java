/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Service.Stub;

import Model.Service.MemberService.MemberService;
import Po.MemberPo;
import Tool.OpMessage;
import Tool.SearchCondition;
import Vo.MemberVo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author dell
 */
public class MemberService_Stub implements MemberService{

    @Override
    public List<MemberVo> searchMember(SearchCondition con) {
        List<MemberVo> lmv=new ArrayList<MemberVo>();//To change body of generated methods, choose Tools | Templates.
        return lmv;
    }

    @Override
    public List<MemberVo> searchMember(String key) {
        List<MemberVo> lmv=new ArrayList<MemberVo>();//To change body of generated methods, choose Tools | Templates.
        return lmv;
    }

    @Override
    public MemberVo getMember(String memberId) {
        String account="";
	String password="";
	String phone="";
	int credit=100;
	int level=1;
	int type=1;//会员类别：企业会员，个人会员
	Date birthday=new Date();
	String enterprise_name="";
        MemberVo mv=new MemberVo(memberId,account,password,phone,credit,level,type,birthday,enterprise_name);
        return mv;
    }

    @Override
    public List<MemberVo> getMembers() {
        List<MemberVo> lmv=new ArrayList<MemberVo>();//To change body of generated methods, choose Tools | Templates.
        return lmv;
    }

    @Override
    public OpMessage addMember(MemberPo member) {
         return new OpMessage();//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage modifyMember(MemberPo member) {
         return new OpMessage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage deleteMember(String memberId) {
         return new OpMessage();//To change body of generated methods, choose Tools | Templates.
    }
    
}
