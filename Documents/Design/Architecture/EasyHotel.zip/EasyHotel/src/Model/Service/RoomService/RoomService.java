package Model.Service.RoomService;

import java.util.List;

import Po.RoomPo;
import Tool.OpMessage;
import Vo.RoomVo;

public interface RoomService {
	public RoomVo getRoom(String roomId);
	public List<RoomVo> getAllRoomsByHotel (String HotelId);
	public OpMessage deleteRoom(String roomId);
	public OpMessage modifyRoom(RoomPo room);
	public OpMessage addRoom(RoomPo room);
}
