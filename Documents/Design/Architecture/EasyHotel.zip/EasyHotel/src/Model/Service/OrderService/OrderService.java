package Model.Service.OrderService;

import java.util.List;

import Po.OrderPo;
import Tool.OpMessage;
import Vo.OrderVo;

public interface OrderService {
	public List<OrderVo> getAllOrdersByCustomer (String customer_Id);
	public List<OrderVo> getAllOrdersByHotel(String hotelId);
	public List<OrderVo> getAllCustomerOrdersByState (String customerId,String state);
	public List<OrderVo> getAllHotelOrdersByState (String hotelId,String state);
	public OrderVo getOrder(String orderId) ;
	public OpMessage placeOrder(OrderPo order,String memberId,String hotelId,String promotionId);
	public OpMessage revokeOrder(String OrderId);
	
}
