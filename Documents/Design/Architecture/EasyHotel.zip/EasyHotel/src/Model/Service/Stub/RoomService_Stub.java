/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Service.Stub;

import Model.Service.RoomService.RoomService;
import Po.RoomPo;
import Tool.OpMessage;
import Vo.RoomVo;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dell
 */
public class RoomService_Stub implements RoomService{

    @Override
    public RoomVo getRoom(String roomId) {
        return new RoomVo(roomId,2,6,500.00);//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RoomVo> getAllRoomsByHotel(String HotelId) {
        List<RoomVo> lrv=new ArrayList<RoomVo>();//To change body of generated methods, choose Tools | Templates.
        return lrv;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage deleteRoom(String roomId) {
         return new OpMessage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage modifyRoom(RoomPo room) {
         return new OpMessage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OpMessage addRoom(RoomPo room) {
         return new OpMessage(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
